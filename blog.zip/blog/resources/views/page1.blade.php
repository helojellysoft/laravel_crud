<!DOCTYPE html>
<html lang="en">
<head>
    <link href="{{ asset('css/one.css') }}" rel="stylesheet"></link>
    <title>Document</title>
</head>
<style>
    .helo{
        color:green;
    }
</style>
<body>
    <h1 class="helo2">Update page is working...:)</h1>
    <form action="" id="register" class="form-horizontal form-label-left" novalidate>
                    
                    {{ csrf_field() }}
            <input type="text" name="t1" id="" value="{{ $disp->stnam }}">
            <input type="submit" value="Update here">@method('GET')

</body>
</html>