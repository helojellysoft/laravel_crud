<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    page 2 is working...
    <a href="<?php echo e(route('index')); ?>">Addnew</a>
<table>
    <tr><th>Name</th>
    <tr><th>Edit/Delete</th></tr>
    <?php $__currentLoopData = $ctrldisp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>

                         
        <td ><?php echo e($dis->stnam); ?></td>
        <td> <a href="<?php echo e(route('deletefun',$dis->id)); ?>" >Delete</a> |||  <a href="<?php echo e(route('editfun',$dis->id)); ?>" >Change</a></td>
      
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
</table>
</body>
</html>


<?php /**PATH C:\xampp\blog\resources\views/page2.blade.php ENDPATH**/ ?>