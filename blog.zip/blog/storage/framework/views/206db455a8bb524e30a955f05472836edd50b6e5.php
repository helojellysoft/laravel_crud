<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/one.css')); ?>" rel="stylesheet"></link>
    <title>Document</title>
</head>
<style>
    .helo{
        color:green;
    }
</style>
<body>
    <h1 class="helo2">Update page is working...:)</h1>
    <form action="" id="register" class="form-horizontal form-label-left" novalidate>
                    
                    <?php echo e(csrf_field()); ?>

            <input type="text" name="t1" id="" value="<?php echo e($disp->stnam); ?>">
            <input type="submit" value="Update here"><?php echo method_field('GET'); ?>

</body>
</html><?php /**PATH C:\xampp\blog\resources\views/page1.blade.php ENDPATH**/ ?>