<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\rubber;

class RubberController extends Controller
{
    public function insertfun(Request $rq){
        $this->validate($rq,[
            'txtnam' => 'required',
            // 'txtph' =
        ]);
        $obj=new rubber;
        $obj->stnam = $rq->txtnam;
        $obj->save();
        return redirect('ctrldisp');
    }

    public function editfun($id){
        $disp = rubber::find($id);
        return view('page1',compact('disp'));
    }    

        
public function page1fun(){
    return view('page1');
    }

  
    public function first(){
        return view('welcome'); // or return redirect('/');
        }
        
        
public function fun2(){
    return view('page2');
}


public function fun4($id){
    $disp = rubber::find($id)->delete();
     return redirect(route('ctrldisp'))->with('alert','Deleted Successfully');
}


public function fun3(){
    $ctrldisp = rubber::all();
    return view('page2',compact('ctrldisp'));
}



}
