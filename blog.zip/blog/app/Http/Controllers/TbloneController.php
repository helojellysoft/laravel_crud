<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\tblone;

class TbloneController extends Controller
{



}

