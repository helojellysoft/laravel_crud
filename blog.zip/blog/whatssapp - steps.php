welcome.blade.php

--------------------------------------------------------
<form action="{{route('insertfun')}}" method="post">
{{csrf_field()}}        //keyword -->security reason
    <input type="text" id="stnam" name="txtnam">
    <button type="submit">submit</button>
    @method('GET')              //GET laravel keyword

web.php
-------------------------------

    Route::get('insertfun','RubberController@insertfun')->name('insertfun');


controller function definition:
----------------------------------
public function insertfun(Request $rq){
        $this->validate($rq,[
            'txtnam' => 'required'  //textbox name keyword -->variable 
        ]);
        $obj=new rubber;  //rubber controller class object create
        $obj->stnam = $rq->txtnam;  //stname -->database table titles
        $obj->save();           //insert into query auto apply
        return redirect('/');
    }

---------------------------------------
database ->migration ->rubber 

